import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'screens/dashboard_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Permission.camera.request();
  runApp(const DriveSafeApp());
}

class DriveSafeApp extends StatelessWidget {
  const DriveSafeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DriveSafe-AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF070B11),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF39FFB0),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const DashboardScreen(),
    );
  }
}
