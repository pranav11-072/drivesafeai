import 'dart:math';

/// Result of one fatigue-engine evaluation.
class FatigueResult {
  final double visionRisk;
  final double leftEyeOpenProb;
  final double rightEyeOpenProb;
  final bool faceDetected;

  FatigueResult({
    required this.visionRisk,
    required this.leftEyeOpenProb,
    required this.rightEyeOpenProb,
    required this.faceDetected,
  });

  static FatigueResult noFace() => FatigueResult(
        visionRisk: 0.0,
        leftEyeOpenProb: 1.0,
        rightEyeOpenProb: 1.0,
        faceDetected: false,
      );
}

/// Driver-tunable thresholds (mirrors EAR_THRESHOLD / MAR_THRESHOLD from the
/// desktop app, adapted to ML Kit's eye-open-probability output).
class FatigueThresholds {
  /// Eyes are considered "closing" below this open-probability.
  final double eyeOpenThreshold;

  /// Smile/mouth-open probability above this is treated as a possible yawn signal.
  final double yawnProbThreshold;

  const FatigueThresholds({
    this.eyeOpenThreshold = 0.45,
    this.yawnProbThreshold = 0.6,
  });

  Map<String, dynamic> toJson() => {
        'eyeOpenThreshold': eyeOpenThreshold,
        'yawnProbThreshold': yawnProbThreshold,
      };

  factory FatigueThresholds.fromJson(Map<String, dynamic> json) =>
      FatigueThresholds(
        eyeOpenThreshold: (json['eyeOpenThreshold'] as num?)?.toDouble() ?? 0.45,
        yawnProbThreshold: (json['yawnProbThreshold'] as num?)?.toDouble() ?? 0.6,
      );

  FatigueThresholds copyWith({double? eyeOpenThreshold, double? yawnProbThreshold}) =>
      FatigueThresholds(
        eyeOpenThreshold: eyeOpenThreshold ?? this.eyeOpenThreshold,
        yawnProbThreshold: yawnProbThreshold ?? this.yawnProbThreshold,
      );
}

/// Computes vision_risk from ML Kit's eye-open probabilities.
/// (ML Kit Face Detection gives eye-open probability directly instead of
/// raw eye landmarks, so this replaces the EAR calculation from the
/// desktop OpenCV/MediaPipe version with an equivalent risk curve.)
FatigueResult evaluateFatigue({
  required double? leftEyeOpenProb,
  required double? rightEyeOpenProb,
  required FatigueThresholds thresholds,
}) {
  if (leftEyeOpenProb == null || rightEyeOpenProb == null) {
    return FatigueResult.noFace();
  }

  final avgOpen = (leftEyeOpenProb + rightEyeOpenProb) / 2.0;

  double eyeRisk = 0.0;
  if (avgOpen < thresholds.eyeOpenThreshold) {
    eyeRisk = ((thresholds.eyeOpenThreshold - avgOpen) / thresholds.eyeOpenThreshold)
        .clamp(0.0, 1.0);
  }

  return FatigueResult(
    visionRisk: eyeRisk,
    leftEyeOpenProb: leftEyeOpenProb,
    rightEyeOpenProb: rightEyeOpenProb,
    faceDetected: true,
  );
}

/// Risk tier, mirrors the Fusion Gate tiers from the desktop app.
enum RiskTier { nominal, warning, critical }

class FusionResult {
  final double totalRisk;
  final RiskTier tier;
  FusionResult(this.totalRisk, this.tier);
}

/// The Fusion Gate: weights vision risk against speed.
/// Identical formula to the desktop app's Fusion Gate.
FusionResult fusionGate(double visionRisk, double speedMph) {
  final speedFactor = min(1.0, speedMph / 65.0);
  final totalRisk = visionRisk * (0.25 + 0.75 * speedFactor);

  RiskTier tier;
  if (totalRisk >= 0.75) {
    tier = RiskTier.critical;
  } else if (totalRisk >= 0.35) {
    tier = RiskTier.warning;
  } else {
    tier = RiskTier.nominal;
  }
  return FusionResult(totalRisk, tier);
}

/// Dynamic Drive Cycle Simulator — identical to the desktop version:
/// 0-8s linear ramp to 45 MPH, then sine-wave highway cruising.
double simulateSpeed(double elapsedSeconds) {
  if (elapsedSeconds < 8.0) {
    return (45.0 / 8.0) * elapsedSeconds;
  }
  final t = elapsedSeconds;
  return 55.0 + 12.0 * sin(t * 0.05) + 4.0 * sin(t * 0.2);
}

/// Rule-based diagnostic log generator (no network, no LLM) —
/// ported 1:1 in spirit from the desktop app's fallback generator.
final _random = Random();

String generateDiagnosticLog(double speed, double visionRisk, double totalRisk) {
  String tierWord;
  String action;
  String cause;

  if (totalRisk >= 0.75) {
    tierWord = 'CRITICAL';
    action = _pick([
      'Issuing escalated audible alert and recommending an immediate stop.',
      'Triggering full alert sequence and logging the event for review.',
      'Engaging maximum-intensity alert; pull over when safe.',
    ]);
    cause =
        'sustained eye-closure signature (vision risk ${(visionRisk * 100).toStringAsFixed(0)}%) '
        'detected at highway speed (${speed.toStringAsFixed(0)} MPH)';
  } else if (totalRisk >= 0.35) {
    tierWord = 'WARNING';
    action = _pick([
      'Issuing a soft audible chime and increasing monitoring sample rate.',
      'Flashing the dashboard indicator and logging the event for trend analysis.',
      'Raising monitoring sensitivity and queuing a follow-up check in 10s.',
    ]);
    cause =
        'elevated fatigue indicators (vision risk ${(visionRisk * 100).toStringAsFixed(0)}%) '
        'combined with current speed of ${speed.toStringAsFixed(0)} MPH';
  } else {
    tierWord = 'NOMINAL';
    action = _pick([
      'No intervention required; continuing standard monitoring cadence.',
      'Maintaining baseline polling rate, all systems nominal.',
      'Standing by, no corrective action needed at this time.',
    ]);
    cause =
        'vision risk (${(visionRisk * 100).toStringAsFixed(0)}%) and speed (${speed.toStringAsFixed(0)} MPH) '
        'remaining within safe operating bounds';
  }

  return 'Total fused risk is ${(totalRisk * 100).toStringAsFixed(0)}% ($tierWord), driven by $cause. $action';
}

String _pick(List<String> options) => options[_random.nextInt(options.length)];
