import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/driver_profile.dart';
import 'fatigue_engine.dart';

class AppSettings {
  bool audibleAlerts;
  double logIntervalSec;
  String activeProfileId;

  AppSettings({
    this.audibleAlerts = true,
    this.logIntervalSec = 4.0,
    required this.activeProfileId,
  });

  Map<String, dynamic> toJson() => {
        'audibleAlerts': audibleAlerts,
        'logIntervalSec': logIntervalSec,
        'activeProfileId': activeProfileId,
      };

  factory AppSettings.fromJson(Map<String, dynamic> json) => AppSettings(
        audibleAlerts: json['audibleAlerts'] as bool? ?? true,
        logIntervalSec: (json['logIntervalSec'] as num?)?.toDouble() ?? 4.0,
        activeProfileId: json['activeProfileId'] as String,
      );
}

/// Handles loading/saving driver profiles, app settings, and appending
/// session telemetry rows — the mobile equivalent of config.json +
/// logs/session_*.csv from the desktop app.
class ConfigService {
  static const _profilesKey = 'drivesafe_profiles';
  static const _settingsKey = 'drivesafe_settings';
  static const _sessionLogPrefix = 'drivesafe_session_log_';

  final _uuid = const Uuid();

  Future<List<DriverProfile>> loadProfiles() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_profilesKey);
    if (raw == null) {
      final defaultProfile = DriverProfile(id: _uuid.v4(), name: 'Default Driver');
      await saveProfiles([defaultProfile]);
      return [defaultProfile];
    }
    final list = jsonDecode(raw) as List;
    return list
        .map((e) => DriverProfile.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> saveProfiles(List<DriverProfile> profiles) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(profiles.map((p) => p.toJson()).toList());
    await prefs.setString(_profilesKey, raw);
  }

  Future<AppSettings> loadSettings(String fallbackProfileId) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_settingsKey);
    if (raw == null) {
      final settings = AppSettings(activeProfileId: fallbackProfileId);
      await saveSettings(settings);
      return settings;
    }
    return AppSettings.fromJson(Map<String, dynamic>.from(jsonDecode(raw)));
  }

  Future<void> saveSettings(AppSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_settingsKey, jsonEncode(settings.toJson()));
  }

  /// Appends one telemetry row to the current session's in-memory CSV log
  /// (held in SharedPreferences as a growing string — fine for session-scale
  /// data; for very long sessions, swap this for sqflite).
  Future<String> startNewSession() async {
    final sessionId = DateTime.now().toIso8601String().replaceAll(':', '-');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      '$_sessionLogPrefix$sessionId',
      'timestamp,elapsed_s,speed_mph,vision_risk,total_risk,tier,profile\n',
    );
    return sessionId;
  }

  Future<void> appendRow(String sessionId, String csvRow) async {
    final prefs = await SharedPreferences.getInstance();
    final key = '$_sessionLogPrefix$sessionId';
    final existing = prefs.getString(key) ?? '';
    await prefs.setString(key, '$existing$csvRow\n');
  }

  Future<String?> getSessionCsv(String sessionId) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('$_sessionLogPrefix$sessionId');
  }

  Future<List<String>> listSessionIds() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs
        .getKeys()
        .where((k) => k.startsWith(_sessionLogPrefix))
        .map((k) => k.substring(_sessionLogPrefix.length))
        .toList();
  }
}
