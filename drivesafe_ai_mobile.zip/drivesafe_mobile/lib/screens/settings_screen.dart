import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/driver_profile.dart';
import '../services/config_service.dart';
import '../services/fatigue_engine.dart';

class SettingsScreen extends StatefulWidget {
  final List<DriverProfile> profiles;
  final AppSettings settings;

  const SettingsScreen({super.key, required this.profiles, required this.settings});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final ConfigService _configService = ConfigService();
  final _uuid = const Uuid();
  late List<DriverProfile> _profiles;
  late AppSettings _settings;
  late String _selectedProfileId;

  @override
  void initState() {
    super.initState();
    _profiles = List.of(widget.profiles);
    _settings = widget.settings;
    _selectedProfileId = _settings.activeProfileId;
  }

  DriverProfile get _selectedProfile =>
      _profiles.firstWhere((p) => p.id == _selectedProfileId, orElse: () => _profiles.first);

  Future<void> _addProfile() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New Driver Profile'),
        content: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Driver name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Add')),
        ],
      ),
    );
    if (name != null && name.trim().isNotEmpty) {
      setState(() {
        final profile = DriverProfile(id: _uuid.v4(), name: name.trim());
        _profiles.add(profile);
        _selectedProfileId = profile.id;
      });
    }
  }

  void _deleteProfile() {
    if (_profiles.length <= 1) return;
    setState(() {
      _profiles.removeWhere((p) => p.id == _selectedProfileId);
      _selectedProfileId = _profiles.first.id;
    });
  }

  Future<void> _save() async {
    _settings.activeProfileId = _selectedProfileId;
    await _configService.saveProfiles(_profiles);
    await _configService.saveSettings(_settings);
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final profile = _selectedProfile;

    return Scaffold(
      backgroundColor: const Color(0xFF070B11),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0C1118),
        title: const Text('Settings'),
        actions: [
          TextButton(onPressed: _save, child: const Text('SAVE', style: TextStyle(color: Color(0xFF39FFB0)))),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Driver Profile', style: TextStyle(color: Color(0xFF7FA1C2), fontSize: 13)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  dropdownColor: const Color(0xFF0C1118),
                  value: _selectedProfileId,
                  items: _profiles
                      .map((p) => DropdownMenuItem(value: p.id, child: Text(p.name, style: const TextStyle(color: Colors.white))))
                      .toList(),
                  onChanged: (v) => setState(() => _selectedProfileId = v!),
                  decoration: const InputDecoration(filled: true, fillColor: Color(0xFF0C1118)),
                ),
              ),
              IconButton(icon: const Icon(Icons.add, color: Colors.white), onPressed: _addProfile),
              IconButton(icon: const Icon(Icons.delete, color: Colors.redAccent), onPressed: _deleteProfile),
            ],
          ),
          const SizedBox(height: 24),
          const Text('Eye-open threshold', style: TextStyle(color: Color(0xFF7FA1C2), fontSize: 13)),
          Slider(
            value: profile.thresholds.eyeOpenThreshold,
            min: 0.1,
            max: 0.8,
            activeColor: const Color(0xFF3BB6FF),
            label: profile.thresholds.eyeOpenThreshold.toStringAsFixed(2),
            onChanged: (v) => setState(() {
              profile.thresholds = profile.thresholds.copyWith(eyeOpenThreshold: v);
            }),
          ),
          const SizedBox(height: 12),
          const Text('Yawn probability threshold', style: TextStyle(color: Color(0xFF7FA1C2), fontSize: 13)),
          Slider(
            value: profile.thresholds.yawnProbThreshold,
            min: 0.2,
            max: 1.0,
            activeColor: const Color(0xFF3BB6FF),
            label: profile.thresholds.yawnProbThreshold.toStringAsFixed(2),
            onChanged: (v) => setState(() {
              profile.thresholds = profile.thresholds.copyWith(yawnProbThreshold: v);
            }),
          ),
          const SizedBox(height: 24),
          SwitchListTile(
            value: _settings.audibleAlerts,
            onChanged: (v) => setState(() => _settings.audibleAlerts = v),
            title: const Text('Audible Critical alerts', style: TextStyle(color: Colors.white)),
            activeColor: const Color(0xFF39FFB0),
          ),
          const SizedBox(height: 12),
          const Text('Diagnostic log interval (seconds)', style: TextStyle(color: Color(0xFF7FA1C2), fontSize: 13)),
          Slider(
            value: _settings.logIntervalSec,
            min: 1,
            max: 15,
            divisions: 14,
            activeColor: const Color(0xFF3BB6FF),
            label: _settings.logIntervalSec.toStringAsFixed(0),
            onChanged: (v) => setState(() => _settings.logIntervalSec = v),
          ),
        ],
      ),
    );
  }
}
