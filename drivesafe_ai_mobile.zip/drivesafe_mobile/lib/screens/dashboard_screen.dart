import 'dart:async';
import 'dart:collection';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:audioplayers/audioplayers.dart';

import '../models/driver_profile.dart';
import '../services/config_service.dart';
import '../services/fatigue_engine.dart';
import '../widgets/speed_gauge.dart';
import '../widgets/risk_graph.dart';
import 'settings_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with WidgetsBindingObserver {
  final ConfigService _configService = ConfigService();
  final FaceDetector _faceDetector = FaceDetector(
    options: FaceDetectorOptions(
      enableClassification: true, // gives eye-open probabilities
      enableLandmarks: true,
      performanceMode: FaceDetectorMode.fast,
    ),
  );
  final AudioPlayer _audioPlayer = AudioPlayer();

  CameraController? _cameraController;
  bool _isDetecting = false;
  String _faceStatus = 'INITIALIZING...';

  List<DriverProfile> _profiles = [];
  late AppSettings _settings;
  DriverProfile? get _activeProfile {
    for (final p in _profiles) {
      if (p.id == _settings.activeProfileId) return p;
    }
    return _profiles.isNotEmpty ? _profiles.first : null;
  }

  double _visionRisk = 0.0;
  double _speed = 0.0;
  double _totalRisk = 0.0;
  RiskTier _tier = RiskTier.nominal;

  final Stopwatch _stopwatch = Stopwatch();
  Timer? _tickTimer;
  double _lastLogTime = 0.0;
  double _lastBeepTime = 0.0;
  String? _sessionId;

  final Queue<double> _visionHistory = Queue<double>();
  final Queue<double> _totalHistory = Queue<double>();
  static const int _maxGraphPoints = 150;

  final List<String> _logLines = [];
  final ScrollController _logScroll = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    _profiles = await _configService.loadProfiles();
    _settings = await _configService.loadSettings(_profiles.first.id);
    _sessionId = await _configService.startNewSession();
    await _initCamera();

    _stopwatch.start();
    _tickTimer = Timer.periodic(const Duration(milliseconds: 200), (_) => _tick());
    if (mounted) setState(() {});
  }

  Future<void> _initCamera() async {
    final cameras = await availableCameras();
    final frontCamera = cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.front,
      orElse: () => cameras.first,
    );
    final controller = CameraController(
      frontCamera,
      ResolutionPreset.medium,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.nv21,
    );
    await controller.initialize();
    await controller.startImageStream(_processCameraImage);
    _cameraController = controller;
    if (mounted) setState(() {});
  }

  Future<void> _processCameraImage(CameraImage image) async {
    if (_isDetecting || _cameraController == null) return;
    _isDetecting = true;
    try {
      final inputImage = _inputImageFromCameraImage(image, _cameraController!);
      if (inputImage == null) return;

      final faces = await _faceDetector.processImage(inputImage);
      if (faces.isEmpty) {
        _faceStatus = 'NO FACE DETECTED';
        final result = FatigueResult.noFace();
        _visionRisk = result.visionRisk;
      } else {
        _faceStatus = 'FACE LOCKED';
        final face = faces.first;
        final thresholds = _activeProfile?.thresholds ?? const FatigueThresholds();
        final result = evaluateFatigue(
          leftEyeOpenProb: face.leftEyeOpenProbability,
          rightEyeOpenProb: face.rightEyeOpenProbability,
          thresholds: thresholds,
        );
        _visionRisk = result.visionRisk;
      }
    } catch (_) {
      // swallow per-frame detection errors; next frame will retry
    } finally {
      _isDetecting = false;
    }
  }

  InputImage? _inputImageFromCameraImage(CameraImage image, CameraController controller) {
    final camera = controller.description;
    final rotation = InputImageRotationValue.fromRawValue(camera.sensorOrientation) ??
        InputImageRotation.rotation0deg;
    final format = InputImageFormatValue.fromRawValue(image.format.raw) ?? InputImageFormat.nv21;

    final plane = image.planes.first;
    return InputImage.fromBytes(
      bytes: plane.bytes,
      metadata: InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: rotation,
        format: format,
        bytesPerRow: plane.bytesPerRow,
      ),
    );
  }

  void _tick() {
    final elapsed = _stopwatch.elapsedMilliseconds / 1000.0;
    _speed = simulateSpeed(elapsed);

    final fusion = fusionGate(_visionRisk, _speed);
    _totalRisk = fusion.totalRisk;
    _tier = fusion.tier;

    _visionHistory.addLast(_visionRisk);
    _totalHistory.addLast(_totalRisk);
    if (_visionHistory.length > _maxGraphPoints) _visionHistory.removeFirst();
    if (_totalHistory.length > _maxGraphPoints) _totalHistory.removeFirst();

    // audible alert on Critical, 3s cooldown
    if (_settings.audibleAlerts && _tier == RiskTier.critical && (elapsed - _lastBeepTime) >= 3.0) {
      _lastBeepTime = elapsed;
      _playAlert();
    }

    // CSV-style session logging
    if (_sessionId != null) {
      final row = [
        DateTime.now().toIso8601String(),
        elapsed.toStringAsFixed(1),
        _speed.toStringAsFixed(1),
        _visionRisk.toStringAsFixed(3),
        _totalRisk.toStringAsFixed(3),
        _tier.index.toString(),
        _activeProfile?.name ?? 'unknown',
      ].join(',');
      _configService.appendRow(_sessionId!, row);
    }

    // diagnostic log every N seconds (rule-based; swap in a cloud/on-device
    // LLM call here later if desired — see README)
    if ((elapsed - _lastLogTime) >= _settings.logIntervalSec) {
      _lastLogTime = elapsed;
      final text = generateDiagnosticLog(_speed, _visionRisk, _totalRisk);
      _appendLog(text);
    }

    if (mounted) setState(() {});
  }

  void _playAlert() {
    _audioPlayer.play(AssetSource('sounds/alert.mp3'));
  }

  void _appendLog(String text) {
    final ts = TimeOfDay.now();
    final tsStr = '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}';
    _logLines.add('[$tsStr] $text');
    if (_logLines.length > 200) _logLines.removeAt(0);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScroll.hasClients) {
        _logScroll.jumpTo(_logScroll.position.maxScrollExtent);
      }
    });
  }

  Color get _tierColor {
    switch (_tier) {
      case RiskTier.critical:
        return const Color(0xFFFF3B3B);
      case RiskTier.warning:
        return const Color(0xFFFFB13B);
      case RiskTier.nominal:
        return const Color(0xFF39FFB0);
    }
  }

  String get _tierText {
    switch (_tier) {
      case RiskTier.critical:
        return 'TIER 3 — CRITICAL';
      case RiskTier.warning:
        return 'TIER 1 — WARNING';
      case RiskTier.nominal:
        return 'TIER 0 — NOMINAL';
    }
  }

  Future<void> _openSettings() async {
    final updated = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => SettingsScreen(profiles: _profiles, settings: _settings),
      ),
    );
    if (updated == true) {
      _profiles = await _configService.loadProfiles();
      _settings = await _configService.loadSettings(_profiles.first.id);
      if (mounted) setState(() {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tickTimer?.cancel();
    _cameraController?.dispose();
    _faceDetector.close();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF070B11),
      body: SafeArea(
        child: Column(
          children: [
            _buildTopBar(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildCameraPanel(),
                    const SizedBox(height: 14),
                    _buildPanel('RISK HISTORY', RiskGraph(
                      visionHistory: _visionHistory,
                      totalHistory: _totalHistory,
                      maxPoints: _maxGraphPoints,
                    )),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(child: _buildPanel('SPEED', Center(child: SpeedGauge(speed: _speed)))),
                      ],
                    ),
                    const SizedBox(height: 14),
                    _buildRiskBar('VISION FATIGUE RISK', _visionRisk, const Color(0xFF3BB6FF)),
                    const SizedBox(height: 14),
                    _buildTotalRiskPanel(),
                    const SizedBox(height: 14),
                    _buildLogPanel(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          const Text('DRIVESAFE-AI',
              style: TextStyle(color: Color(0xFF39FFB0), fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2)),
          const Spacer(),
          Text('Driver: ${_activeProfile?.name ?? "—"}',
              style: const TextStyle(color: Color(0xFF7FA1C2), fontSize: 12)),
          IconButton(
            icon: const Icon(Icons.settings, color: Color(0xFFE8F1FF)),
            onPressed: _openSettings,
          ),
        ],
      ),
    );
  }

  Widget _buildCameraPanel() {
    return _buildPanel(
      'LIVE DRIVER FEED',
      Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SizedBox(
              height: 320,
              width: double.infinity,
              child: _cameraController != null && _cameraController!.value.isInitialized
                  ? CameraPreview(_cameraController!)
                  : const Center(
                      child: CircularProgressIndicator(color: Color(0xFF39FFB0)),
                    ),
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(_faceStatus, style: const TextStyle(color: Color(0xFF5D7A99), fontSize: 12)),
          ),
        ],
      ),
    );
  }

  Widget _buildRiskBar(String title, double value, Color color) {
    return _buildPanel(
      title,
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: value.clamp(0.0, 1.0),
              minHeight: 18,
              backgroundColor: const Color(0xFF0C1118),
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
          const SizedBox(height: 4),
          Text('${(value * 100).toStringAsFixed(0)}%',
              style: const TextStyle(color: Color(0xFF7FA1C2), fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildTotalRiskPanel() {
    return _buildPanel(
      'FUSED TOTAL RISK',
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: _totalRisk.clamp(0.0, 1.0),
              minHeight: 18,
              backgroundColor: const Color(0xFF0C1118),
              valueColor: AlwaysStoppedAnimation<Color>(_tierColor),
            ),
          ),
          const SizedBox(height: 8),
          Text(_tierText, style: TextStyle(color: _tierColor, fontWeight: FontWeight.bold, fontSize: 15)),
        ],
      ),
    );
  }

  Widget _buildLogPanel() {
    return _buildPanel(
      'AI DIAGNOSTIC LOG',
      SizedBox(
        height: 220,
        child: ListView.builder(
          controller: _logScroll,
          itemCount: _logLines.length,
          itemBuilder: (context, i) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Text(
              _logLines[i],
              style: const TextStyle(color: Color(0xFFE8F1FF), fontSize: 12, fontFamily: 'monospace'),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPanel(String title, Widget child) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0C1118),
        border: Border.all(color: const Color(0xFF1D2733)),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  color: Color(0xFF7FA1C2), fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1)),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}
