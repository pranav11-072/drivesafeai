import 'dart:math';
import 'package:flutter/material.dart';

class SpeedGauge extends StatelessWidget {
  final double speed;
  final double maxSpeed;

  const SpeedGauge({super.key, required this.speed, this.maxSpeed = 120});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 200,
      height: 200,
      child: CustomPaint(
        painter: _GaugePainter(speed: speed.clamp(0, maxSpeed), maxSpeed: maxSpeed),
      ),
    );
  }
}

class _GaugePainter extends CustomPainter {
  final double speed;
  final double maxSpeed;
  _GaugePainter({required this.speed, required this.maxSpeed});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = min(size.width, size.height) / 2 - 14;
    final rect = Rect.fromCircle(center: center, radius: radius);

    const startAngle = 135 * pi / 180; // matches the desktop 225°/-270° sweep
    const sweepAngle = 270 * pi / 180;

    final bgPaint = Paint()
      ..color = const Color(0xFF1D2733)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(rect, startAngle, sweepAngle, false, bgPaint);

    final frac = (speed / maxSpeed).clamp(0.0, 1.0);
    Color valueColor = const Color(0xFF39FFB0);
    if (speed >= 85) {
      valueColor = const Color(0xFFFF3B3B);
    } else if (speed >= 65) {
      valueColor = const Color(0xFFFFB13B);
    }

    final valuePaint = Paint()
      ..color = valueColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(rect, startAngle, sweepAngle * frac, false, valuePaint);

    // needle
    final needleAngle = startAngle + sweepAngle * frac;
    final needleLen = radius - 20;
    final needleEnd = Offset(
      center.dx + needleLen * cos(needleAngle),
      center.dy + needleLen * sin(needleAngle),
    );
    final needlePaint = Paint()
      ..color = const Color(0xFFE8F1FF)
      ..strokeWidth = 3;
    canvas.drawLine(center, needleEnd, needlePaint);
    canvas.drawCircle(center, 5, Paint()..color = const Color(0xFFE8F1FF));

    // speed text
    final tp = TextPainter(
      text: TextSpan(
        text: speed.toStringAsFixed(0),
        style: const TextStyle(
          color: Color(0xFFE8F1FF),
          fontSize: 32,
          fontWeight: FontWeight.bold,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(center.dx - tp.width / 2, center.dy - 10));

    final tp2 = TextPainter(
      text: const TextSpan(
        text: 'MPH',
        style: TextStyle(color: Color(0xFF7FA1C2), fontSize: 12),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp2.paint(canvas, Offset(center.dx - tp2.width / 2, center.dy + 22));
  }

  @override
  bool shouldRepaint(covariant _GaugePainter oldDelegate) =>
      oldDelegate.speed != speed;
}
