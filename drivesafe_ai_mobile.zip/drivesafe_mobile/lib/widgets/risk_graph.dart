import 'package:flutter/material.dart';
import 'dart:collection';

class RiskGraph extends StatelessWidget {
  final Queue<double> visionHistory;
  final Queue<double> totalHistory;
  final int maxPoints;

  const RiskGraph({
    super.key,
    required this.visionHistory,
    required this.totalHistory,
    this.maxPoints = 150,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 130,
      width: double.infinity,
      child: CustomPaint(
        painter: _GraphPainter(
          visionHistory: visionHistory,
          totalHistory: totalHistory,
          maxPoints: maxPoints,
        ),
      ),
    );
  }
}

class _GraphPainter extends CustomPainter {
  final Queue<double> visionHistory;
  final Queue<double> totalHistory;
  final int maxPoints;

  _GraphPainter({
    required this.visionHistory,
    required this.totalHistory,
    required this.maxPoints,
  });

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..color = const Color(0xFF05080D),
    );

    final gridPaint = Paint()
      ..color = const Color(0xFF1D2733)
      ..strokeWidth = 1;
    for (final frac in [0.25, 0.5, 0.75]) {
      final y = size.height - frac * size.height;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    void drawSeries(Queue<double> hist, Color color) {
      if (hist.length < 2) return;
      final step = size.width / (maxPoints - 1);
      final offset = (maxPoints - hist.length) * step;
      final path = Path();
      final values = hist.toList();
      for (var i = 0; i < values.length; i++) {
        final x = offset + i * step;
        final y = size.height - (values[i] * size.height);
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }

    drawSeries(visionHistory, const Color(0xFF3BB6FF));
    drawSeries(totalHistory, const Color(0xFF39FFB0));

    final visionLabel = TextPainter(
      text: const TextSpan(
        text: '● Vision Risk',
        style: TextStyle(color: Color(0xFF3BB6FF), fontSize: 11),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    visionLabel.paint(canvas, const Offset(6, 4));

    final totalLabel = TextPainter(
      text: const TextSpan(
        text: '● Total Risk',
        style: TextStyle(color: Color(0xFF39FFB0), fontSize: 11),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    totalLabel.paint(canvas, const Offset(100, 4));
  }

  @override
  bool shouldRepaint(covariant _GraphPainter oldDelegate) => true;
}
