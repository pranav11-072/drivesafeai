import 'fatigue_engine.dart';

class DriverProfile {
  final String id;
  String name;
  FatigueThresholds thresholds;

  DriverProfile({
    required this.id,
    required this.name,
    FatigueThresholds? thresholds,
  }) : thresholds = thresholds ?? const FatigueThresholds();

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'thresholds': thresholds.toJson(),
      };

  factory DriverProfile.fromJson(Map<String, dynamic> json) => DriverProfile(
        id: json['id'] as String,
        name: json['name'] as String,
        thresholds: FatigueThresholds.fromJson(
          Map<String, dynamic>.from(json['thresholds'] as Map),
        ),
      );
}
